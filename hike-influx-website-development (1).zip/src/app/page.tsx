import MonelloWorldSite from "@/components/HikeInfluxSite";

export const dynamic = "force-dynamic";

export default function Page() {
  return <MonelloWorldSite />;
}
